import React from 'react';

class ProductAdd extends React.Component {
    render() {
        return (
            <div>
                ProductAdd
            </div>
        );
    }
}
export default ProductAdd;