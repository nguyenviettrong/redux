import React from 'react';

class NotFound extends React.Component {
    render() {
        return (
            <div>
                NotFound
            </div>
        );
    }
}
export default NotFound;