import React from 'react';

class Brand extends React.Component {
    render() {
        return (
            <div className="brands_products">
                <h2>Brands</h2>
            </div>
        );
    }
}
export default Brand;