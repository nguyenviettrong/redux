import React from 'react';

class Shipping extends React.Component {
    render() {
        return (
            <div className="shipping text-center">
                <img src="images/home/shipping.jpg" alt="" />
            </div>
        );
    }
}
export default Shipping;