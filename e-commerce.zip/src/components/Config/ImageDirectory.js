export default function ImageDirectory (folder) {
    return (
        'http://nguyenviettrong.com/upload/' + folder
    )
}
