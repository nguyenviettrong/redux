// import React from 'react'
// const AppContext = React.createContext({})
// export const AppProvider = AppContext.Provider
// export const AppConsumer = AppContext.Consumer
// export default AppContext

import React from 'react'
export const AppContext = React.createContext()
// class AppProvider extends React.Component {
//   state = { isLoggedIn: false }
  
//   handlelogOut = () => {
//         localStorage.setItem('appState','')
//         localStorage.clear();
//         this.setState({
//             isLoggedIn: false
//         })
//   }
//   handlelogIn = () => {
//     this.setState({
//         isLoggedIn: true
//     })
//   }
  
//   render() {
//     const token = localStorage.getItem('appState');
//     let isLoggedIn = false
//     if(token == null){
//         isLoggedIn = false
//     }else{
//         isLoggedIn = true
//     }
//     const value = {
//       isLoggedIn : isLoggedIn,
//       handlelogIn: this.handlelogIn,
//       handlelogOut: this.handlelogOut
//     }

//     return (
//       <AppContext.Provider
//         value={value}
//       >
//         {this.props.children}
//       </AppContext.Provider>
//     )
//   }
// }

// const AppConsumer = AppContext.Consumer

// export { AppProvider, AppConsumer }
