import React from 'react';
import CallApi from '../Config/API';
import ImageDirectory from '../Config/ImageDirectory';
class Index extends React.Component {
    constructor(props){
        super(props);
        this.state = {
            dataProducts: [],
            activePage: 1,
            itemsCountPerPage: '',
            totalItemsCount: '',
        }
    }

    componentDidMount(){
        CallApi('GET','product', '')
        .then(response => {
            // console.log(response)
            this.setState({
                dataProducts: response.data.data,
                itemsCountPerPage: 10,
                totalItemsCount: 10
            })
        })
        .catch(error => {
            console.log(error)
        })
    }

    render() {
       let itemProduct = null
        if(this.state.dataProducts && Array.isArray(this.state.dataProducts)) {
            itemProduct = this.state.dataProducts.map((item,index) => 
                <tr>
                    <td className="cart_product">
                        <a href><img src="images/cart/one.png" alt="" /></a>
                    </td>
                    <td className="cart_description">
                        <h4><a href>{item.name}</a></h4>
                    </td>
                    <td className="cart_price">
                        <p>{item.price}</p>
                    </td>
                    <td className="cart_quantity">
                        <a id={item.id}><i className="fa fa-pencil"></i></a>
                    </td>
                    <td className="cart_delete">
                        <a id={item.id} className="cart_quantity_delete" href><i className="fa fa-times" /></a>
                    </td>
                </tr>
            )
        }
        return (
            <div>
                <div className="container">
                    <div className="row">
                        <div className="col-sm-3">
                            {/* <button onClick={this.logOut}>Logout</button> */}
                            <div className="panel-group category-products" id="accordian">
                                <div className="panel panel-default">                                
                                    <div className="panel-body">
                                        <ul>
                                            <li><a><i className="fa fa-angle-right"></i> My profile </a></li>
                                            <li><a><i className="fa fa-angle-right"></i> All products </a></li>
                                            <li><a><i className="fa fa-angle-right"></i> Add new product</a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div id="cart_items" className="col-sm-9 ">
                            {/* <Info_user /> */}
                            <div className="table-responsive cart_info">
                                <table className="table table-condensed">
                                    <thead>
                                    <tr className="cart_menu">
                                        <td className="image">Image</td>
                                        <td className="description">Name</td>
                                        <td className="price">Price</td>
                                        <td className="quantity">Edit</td>
                                        <td className="total">Delete</td>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    {itemProduct}
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}
export default Index;