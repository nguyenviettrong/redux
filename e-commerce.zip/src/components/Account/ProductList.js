import React from 'react';

class ProductList extends React.Component {
    render() {
        return (
            <div>
                ProductList
            </div>
        );
    }
}
export default ProductList;