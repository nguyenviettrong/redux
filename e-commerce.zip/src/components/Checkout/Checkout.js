import React from 'react';

class Checkout extends React.Component {
    render() {
        return (
            <div>
                Checkout
            </div>
        );
    }
}
export default Checkout;