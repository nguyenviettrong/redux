import React from 'react';

class CartList extends React.Component {
    render() {
        return (
            <div>
                CartList
            </div>
        );
    }
}
export default CartList;