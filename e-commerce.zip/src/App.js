import React from 'react';
import HeaderTop from './components/Layout/Header/HeaderTop';
import HeaderMiddle from './components/Layout/Header/HeaderMiddle';
import HeaderBottom from './components/Layout/Header/HeaderBottom';
import Footer from './components/Layout/Footer';
import ReactNotification from 'react-notifications-component'
import 'react-notifications-component/dist/theme.css'
import { AppContext } from './components/AppContext'
import {
  withRouter
} from "react-router-dom";

class App extends React.Component {

  logoutContext = (value) => {
    localStorage['isLoggedIn'] = '';
    console.log("logout:" + value)
  }
  loginContext = (value) => {
    console.log("login:" + value) 
    localStorage['isLoggedIn'] = JSON.stringify(value)
  }

  render() {
    
    return (
      <AppContext.Provider value={{
        loginContext: this.loginContext,
        logoutContext: this.logoutContext
      }}>
        <div>
          <header id="header">
              <HeaderTop />
              <HeaderMiddle />
              <HeaderBottom />
              <ReactNotification />
            </header>
            {this.props.children}
            <Footer />
        </div>
      </AppContext.Provider>
    );
  }
}
export default withRouter(App);
